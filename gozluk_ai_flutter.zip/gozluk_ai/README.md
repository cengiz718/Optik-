# Gözlük Deneme — canlı deneme + yüze uyum puanı

Müşteri ön kamerayla gözlüğü canlı takar; uygulama yüz şeklini bulur, her modele
100 üzerinden uyum puanı verir ve "Sana en yakışan" modeli işaretler.

## APK üretme (bilgisayarda, bir kez)
1. Flutter SDK (3.22+) ve Android Studio kurun, `flutter doctor` temiz olsun.
2. Bu klasörde:
   ```
   flutter create . --org com.dukkaniniz --project-name gozluk_ai --platforms android
   flutter pub get
   ```
3. `android/app/build.gradle(.kts)` içinde `minSdk` değerini **24** yapın.
4. Telefonu USB ile bağlayıp deneyin: `flutter run`
5. APK: `flutter build apk --release`
   Dosya: `build/app/outputs/flutter-apk/app-release.apk`

Derleme hatası olursa hata metnini Claude'a (veya Claude Code'a) yapıştırın.

## Kendi dükkanınıza uyarlama
- **Model listesi:** `lib/models/models.dart` içindeki `kCatalog` (kod, ad, şekil, lens-köprü-yükseklik mm, fiyat, renk).
- **Gerçek gözlük görseli:** `lib/ui/glasses_painter.dart` şimdilik gözlüğü çizerek üretir. Şeffaf PNG kullanmak için `drawGlasses` içinde `drawImageRect` kullanın.
- **Puan kuralları:** `lib/services/scoring.dart` (şekil uyumu 55 + boyut 30 + göz hizası 15).
- **Yüz şekli eşikleri:** `lib/services/face_analyzer.dart` → `FaceConfig`.
  Üstteki "Yüz şekli" etiketine dokununca ham oranlar görünür; 10-20 müşteriyle bakıp eşikleri ayarlayın.
- **Boyut doğruluğu:** sağ üstteki cetvel simgesinden müşterinin elmacık genişliğini (mm) girin.

## Notlar
- Tüm analiz cihazda yapılır, görüntü kaydedilmez/gönderilmez (KVKK açısından rahat).
  Fotoğraf saklayacaksanız açık rıza metni ekleyin.
- Puan bir yardımcıdır; beğeni kişiseldir. Son söz müşterinin.
- Sonraki adımlar: fotoğraf çekip paylaşma, yan yana kolaj, stok/fiyat senkronu, kişisel not.
