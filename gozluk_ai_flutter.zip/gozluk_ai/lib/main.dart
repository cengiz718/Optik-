import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'models/models.dart';
import 'ui/tryon_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  final cameras = await availableCameras();
  runApp(GozlukApp(cameras: cameras));
}

class GozlukApp extends StatelessWidget {
  final List<CameraDescription> cameras;
  const GozlukApp({super.key, required this.cameras});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Gözlük Deneme',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorSchemeSeed: kAccent,
      ),
      home: cameras.isEmpty
          ? const Scaffold(body: Center(child: Text('Bu cihazda kamera bulunamadı')))
          : TryOnScreen(
              camera: cameras.firstWhere(
                (c) => c.lensDirection == CameraLensDirection.front,
                orElse: () => cameras.first,
              ),
            ),
    );
  }
}
