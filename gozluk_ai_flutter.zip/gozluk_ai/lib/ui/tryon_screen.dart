import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:google_mlkit_commons/google_mlkit_commons.dart';
import 'package:google_mlkit_face_mesh_detection/google_mlkit_face_mesh_detection.dart';
import '../models/models.dart';
import '../services/face_analyzer.dart';
import '../services/scoring.dart';
import 'glasses_painter.dart';

class TryOnScreen extends StatefulWidget {
  final CameraDescription camera;
  const TryOnScreen({super.key, required this.camera});

  @override
  State<TryOnScreen> createState() => _TryOnScreenState();
}

class _TryOnScreenState extends State<TryOnScreen> {
  CameraController? _cam;
  final _detector = FaceMeshDetector(option: FaceMeshDetectorOptions.faceMesh);
  final _agg = FaceAggregator();
  bool _busy = false, _debug = false;
  int _misses = 0, _selected = 0;
  FaceGeometry? _geo;
  double _faceMm = 138; // elmacık kemikleri arası ortalama genişlik
  String? _error;

  @override
  void initState() {
    super.initState();
    _start();
  }

  Future<void> _start() async {
    try {
      final cam = CameraController(
        widget.camera,
        ResolutionPreset.medium,
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.nv21,
      );
      await cam.initialize();
      await cam.startImageStream(_onFrame);
      if (!mounted) return;
      setState(() => _cam = cam);
    } catch (e) {
      if (mounted) setState(() => _error = 'Kamera açılamadı. Kamera iznini kontrol edin.\n$e');
    }
  }

  InputImage? _toInput(CameraImage img) {
    final rotation =
        InputImageRotationValue.fromRawValue(widget.camera.sensorOrientation);
    if (rotation == null || img.planes.length != 1) return null;
    final plane = img.planes.first;
    return InputImage.fromBytes(
      bytes: plane.bytes,
      metadata: InputImageMetadata(
        size: Size(img.width.toDouble(), img.height.toDouble()),
        rotation: rotation,
        format: InputImageFormat.nv21,
        bytesPerRow: plane.bytesPerRow,
      ),
    );
  }

  Future<void> _onFrame(CameraImage img) async {
    if (_busy || !mounted) return;
    _busy = true;
    try {
      final input = _toInput(img);
      if (input == null) return;
      final meshes = await _detector.processImage(input);
      if (!mounted) return;
      if (meshes.isEmpty) {
        if (++_misses > 10) {
          _agg.reset();
          setState(() => _geo = null);
        }
        return;
      }
      _misses = 0;
      final sideways = widget.camera.sensorOrientation % 180 == 90;
      final size = sideways
          ? Size(img.height.toDouble(), img.width.toDouble())
          : Size(img.width.toDouble(), img.height.toDouble());
      final g = FaceGeometry.fromMesh(meshes.first, size).smoothed(_geo);
      _agg.add(g);
      setState(() => _geo = g);
    } catch (_) {
      // tek kare hatası önemsiz, bir sonraki kareyle devam
    } finally {
      _busy = false;
    }
  }

  @override
  void dispose() {
    _cam?.dispose();
    _detector.close();
    super.dispose();
  }

  // ---------- Arayüz ----------

  @override
  Widget build(BuildContext context) {
    if (_error != null) {
      return Scaffold(
          body: Center(
              child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text(_error!, textAlign: TextAlign.center))));
    }
    final cam = _cam;
    if (cam == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final geo = _geo, shape = _agg.shape;
    final scores = (geo != null && shape != null)
        ? [for (final f in kCatalog) scoreFrame(f, shape, geo, _faceMm)]
        : null;
    var best = -1;
    if (scores != null) {
      best = 0;
      for (var i = 1; i < scores.length; i++) {
        if (scores[i].total > scores[best].total) best = i;
      }
    }
    final ps = cam.value.previewSize!;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(children: [
        Positioned.fill(
          child: ClipRect(
            child: FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: ps.height,
                height: ps.width,
                child: Stack(fit: StackFit.expand, children: [
                  CameraPreview(cam),
                  CustomPaint(painter: TryOnPainter(geo, kCatalog[_selected], _faceMm)),
                ]),
              ),
            ),
          ),
        ),
        Positioned(
          top: 0, left: 0, right: 0,
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
              child: Row(children: [
                GestureDetector(
                  onTap: () => setState(() => _debug = !_debug),
                  child: _glass(Text(_status(geo, shape), style: const TextStyle(fontSize: 13))),
                ),
                const Spacer(),
                _glass(
                  GestureDetector(
                    onTap: _openSettings,
                    child: const Icon(Icons.straighten, size: 20),
                  ),
                ),
              ]),
            ),
          ),
        ),
        Positioned(
          bottom: 0, left: 0, right: 0,
          child: DecoratedBox(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0x00000000), Color(0xCC000000)],
              ),
            ),
            child: SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.only(top: 24, bottom: 10),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  if (scores != null) _scoreCard(scores[_selected], kCatalog[_selected], _selected == best),
                  const SizedBox(height: 8),
                  SizedBox(
                    height: 100,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      itemCount: kCatalog.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 8),
                      itemBuilder: (_, i) => _card(i, scores?[i], i == best),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: SizedBox(
                      width: double.infinity,
                      child: FilledButton(
                        style: FilledButton.styleFrom(
                          backgroundColor: kAccent,
                          foregroundColor: Colors.black,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                        ),
                        onPressed: scores == null ? null : () => _openCompare(scores),
                        child: const Text('Tüm modelleri karşılaştır'),
                      ),
                    ),
                  ),
                ]),
              ),
            ),
          ),
        ),
      ]),
    );
  }

  String _status(FaceGeometry? geo, FaceShape? shape) {
    if (geo == null) return 'Yüzünüzü çerçeveye alın';
    if (shape == null) return 'Yüz analiz ediliyor…';
    final base = 'Yüz şekli: ${shape.tr}';
    return _debug
        ? '$base  (${_agg.length.toStringAsFixed(2)} / ${_agg.jaw.toStringAsFixed(2)} / ${_agg.forehead.toStringAsFixed(2)})'
        : base;
  }

  Widget _glass(Widget child) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.black.withAlpha(140),
          borderRadius: BorderRadius.circular(20),
        ),
        child: child,
      );

  Widget _scoreCard(FitScore s, EyeFrame f, bool isBest) => Container(
        margin: const EdgeInsets.symmetric(horizontal: 12),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.black.withAlpha(160),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: isBest ? kAccent : Colors.white24),
        ),
        child: Row(children: [
          SizedBox(
            width: 56,
            height: 56,
            child: Stack(alignment: Alignment.center, children: [
              SizedBox(
                width: 56,
                height: 56,
                child: CircularProgressIndicator(
                  value: s.total / 100,
                  strokeWidth: 5,
                  color: kAccent,
                  backgroundColor: Colors.white12,
                ),
              ),
              Text('${s.total}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            ]),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Flexible(
                  child: Text('${f.name} · ${f.shape.tr}',
                      style: const TextStyle(fontWeight: FontWeight.w700), overflow: TextOverflow.ellipsis),
                ),
                if (isBest) ...[
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(color: kAccent, borderRadius: BorderRadius.circular(10)),
                    child: const Text('Sana en yakışan',
                        style: TextStyle(color: Colors.black, fontSize: 11, fontWeight: FontWeight.w600)),
                  ),
                ],
              ]),
              const SizedBox(height: 4),
              for (final r in s.reasons)
                Text(r, style: const TextStyle(fontSize: 12, color: Colors.white70)),
            ]),
          ),
        ]),
      );

  Widget _card(int i, FitScore? s, bool isBest) {
    final f = kCatalog[i];
    final sel = i == _selected;
    return GestureDetector(
      onTap: () => setState(() => _selected = i),
      child: Container(
        width: 118,
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Colors.black.withAlpha(sel ? 190 : 120),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: sel ? kAccent : Colors.white24, width: sel ? 1.8 : 1),
        ),
        child: Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          SizedBox(height: 38, width: double.infinity, child: CustomPaint(painter: FramePreviewPainter(f))),
          Text(f.name, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Text('₺${f.price.round()}', style: const TextStyle(fontSize: 11, color: Colors.white70)),
            if (s != null) ...[
              const SizedBox(width: 6),
              Text('${s.total}',
                  style: TextStyle(
                      fontSize: 12, fontWeight: FontWeight.w700, color: isBest ? kAccent : Colors.white)),
            ],
          ]),
        ]),
      ),
    );
  }

  void _openCompare(List<FitScore> scores) {
    final order = List<int>.generate(kCatalog.length, (i) => i)
      ..sort((a, b) => scores[b].total.compareTo(scores[a].total));
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF15171C),
      isScrollControlled: true,
      builder: (ctx) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          padding: const EdgeInsets.all(16),
          children: [
            const Text('Yüzünüze uyum sırası', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            for (var rank = 0; rank < order.length; rank++)
              InkWell(
                onTap: () {
                  setState(() => _selected = order[rank]);
                  Navigator.pop(ctx);
                },
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Row(children: [
                    SizedBox(width: 22, child: Text('${rank + 1}', style: const TextStyle(color: Colors.white54))),
                    SizedBox(
                      width: 72,
                      height: 34,
                      child: CustomPaint(painter: FramePreviewPainter(kCatalog[order[rank]])),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('${kCatalog[order[rank]].name}  ₺${kCatalog[order[rank]].price.round()}',
                            style: const TextStyle(fontWeight: FontWeight.w600)),
                        const SizedBox(height: 6),
                        LinearProgressIndicator(
                          value: scores[order[rank]].total / 100,
                          minHeight: 6,
                          color: rank == 0 ? kAccent : Colors.white38,
                          backgroundColor: Colors.white12,
                          borderRadius: BorderRadius.circular(3),
                        ),
                      ]),
                    ),
                    const SizedBox(width: 12),
                    Text('${scores[order[rank]].total}',
                        style: TextStyle(fontWeight: FontWeight.w700, color: rank == 0 ? kAccent : Colors.white)),
                  ]),
                ),
              ),
          ],
        ),
      ),
    );
  }

  void _openSettings() {
    showDialog(
      context: context,
      builder: (ctx) {
        var v = _faceMm;
        return StatefulBuilder(
          builder: (ctx, set) => AlertDialog(
            title: const Text('Yüz genişliği'),
            content: Column(mainAxisSize: MainAxisSize.min, children: [
              const Text(
                  'Müşterinin elmacık kemikleri arasını cetvelle ölçüp girin. Boyut puanı buna göre hesaplanır.',
                  style: TextStyle(fontSize: 13)),
              Slider(value: v, min: 120, max: 160, divisions: 40, label: '${v.round()}', onChanged: (x) => set(() => v = x)),
              Text('${v.round()} mm'),
            ]),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Vazgeç')),
              FilledButton(
                onPressed: () {
                  setState(() => _faceMm = v);
                  Navigator.pop(ctx);
                },
                child: const Text('Kaydet'),
              ),
            ],
          ),
        );
      },
    );
  }
}
