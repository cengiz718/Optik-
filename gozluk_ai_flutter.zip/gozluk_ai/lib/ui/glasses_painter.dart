import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/face_analyzer.dart';

/// Gözlüğü milimetre biriminde çizer; pxPerMm ile ölçeklenir.
/// Gerçek katalog fotoğrafları (şeffaf PNG) hazır olunca bu fonksiyon
/// canvas.drawImageRect ile değiştirilebilir.
void drawGlasses(Canvas canvas, EyeFrame f, Offset center, double pxPerMm, double angle) {
  canvas.save();
  canvas.translate(center.dx, center.dy);
  canvas.rotate(angle);
  canvas.scale(pxPerMm);

  final rim = Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = 2.4
    ..strokeJoin = StrokeJoin.round
    ..strokeCap = StrokeCap.round
    ..color = f.color;
  final tint = Paint()..color = f.color.withAlpha(34);
  final shine = Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = 1.2
    ..strokeCap = StrokeCap.round
    ..color = Colors.white.withAlpha(90);

  final h = f.heightMm;
  for (final s in const [-1.0, 1.0]) {
    canvas.save();
    canvas.translate(s * f.pdMm / 2, 0);
    canvas.scale(s, 1);
    final lens = _lensPath(f);
    canvas.drawPath(lens, tint);
    canvas.drawPath(lens, rim);
    canvas.drawArc(
      Rect.fromCenter(center: Offset.zero, width: f.lensMm * 0.7, height: h * 0.7),
      math.pi * 1.1, math.pi * 0.25, false, shine);
    canvas.restore();
  }

  final bridge = Path()
    ..moveTo(-f.bridgeMm / 2, -h * 0.10)
    ..quadraticBezierTo(0, -h * 0.32, f.bridgeMm / 2, -h * 0.10);
  canvas.drawPath(bridge, rim);

  final edge = (f.pdMm + f.lensMm) / 2;
  for (final s in const [-1.0, 1.0]) {
    canvas.drawLine(Offset(s * edge, -h * 0.22), Offset(s * (edge + 6), -h * 0.24), rim);
  }
  canvas.restore();
}

/// Lens yolu: dış kenar her zaman +x yönündedir (sol lens için ayna çevrilir).
Path _lensPath(EyeFrame f) {
  final w = f.lensMm, h = f.heightMm;
  final l = -w / 2, r = w / 2, t = -h / 2, b = h / 2;
  switch (f.shape) {
    case FrameShape.round:
    case FrameShape.oval:
      return Path()..addOval(Rect.fromLTRB(l, t, r, b));
    case FrameShape.square:
      return Path()..addRRect(RRect.fromLTRBR(l, t, r, b, const Radius.circular(5)));
    case FrameShape.rectangle:
      return Path()..addRRect(RRect.fromLTRBR(l, t, r, b, const Radius.circular(3)));
    case FrameShape.aviator:
      return Path()
        ..moveTo(l, t + h * .18)
        ..quadraticBezierTo(l, t, l + w * .18, t)
        ..lineTo(r - w * .18, t)
        ..quadraticBezierTo(r, t, r, t + h * .18)
        ..cubicTo(r, t + h * .75, w * .2, b, 0, b)
        ..cubicTo(-w * .2, b, l, t + h * .75, l, t + h * .18)
        ..close();
    case FrameShape.catEye:
      return Path()
        ..moveTo(l, t + h * .32)
        ..quadraticBezierTo(l, t + h * .04, l + w * .28, t + h * .02)
        ..quadraticBezierTo(r - w * .25, t - h * .02, r + w * .03, t - h * .16)
        ..quadraticBezierTo(r + w * .03, t + h * .6, r - w * .22, b - h * .04)
        ..quadraticBezierTo(l + w * .4, b + h * .02, l + w * .04, b - h * .18)
        ..quadraticBezierTo(l - w * .03, t + h * .7, l, t + h * .32)
        ..close();
  }
}

/// Canlı kamera üstünde gözlük. Ön kamera aynalı gösterildiği için x ters çevrilir.
class TryOnPainter extends CustomPainter {
  final FaceGeometry? geo;
  final EyeFrame frame;
  final double faceMm;
  TryOnPainter(this.geo, this.frame, this.faceMm);

  @override
  void paint(Canvas canvas, Size size) {
    final g = geo;
    if (g == null) return;
    final k = size.width / g.imageSize.width;
    final c = Offset((g.imageSize.width - g.eyeCenter.dx) * k, g.eyeCenter.dy * k);
    drawGlasses(canvas, frame, c, g.cheekPx * k / faceMm, -g.rollRad);
  }

  @override
  bool shouldRepaint(covariant TryOnPainter old) => true;
}

/// Katalog kartındaki küçük önizleme.
class FramePreviewPainter extends CustomPainter {
  final EyeFrame frame;
  FramePreviewPainter(this.frame);

  @override
  void paint(Canvas canvas, Size size) =>
      drawGlasses(canvas, frame, size.center(Offset.zero), size.width / (frame.totalWidthMm * 1.06), 0);

  @override
  bool shouldRepaint(covariant FramePreviewPainter old) => old.frame != frame;
}
