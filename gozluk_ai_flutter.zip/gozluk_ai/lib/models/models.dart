import 'package:flutter/painting.dart';

const kAccent = Color(0xFF6FD3C4);

enum FaceShape { oval, round, square, heart, oblong }

// Sıra: round, oval, square, rectangle, aviator, catEye (skor matrisi bu sıraya bağlı)
enum FrameShape { round, oval, square, rectangle, aviator, catEye }

extension FaceShapeX on FaceShape {
  String get tr => const ['oval', 'yuvarlak', 'kare', 'kalp', 'uzun'][index];
}

extension FrameShapeX on FrameShape {
  String get tr =>
      const ['Yuvarlak', 'Oval', 'Kare', 'Dikdörtgen', 'Aviator', 'Kedi gözü'][index];
}

/// Dükkandaki bir gözlük modeli. Ölçüler milimetre (etiketin üstündeki 52-18-140 gibi).
class EyeFrame {
  final String code, name;
  final FrameShape shape;
  final double lensMm, bridgeMm, heightMm, price;
  final Color color;

  const EyeFrame({
    required this.code,
    required this.name,
    required this.shape,
    required this.lensMm,
    required this.bridgeMm,
    required this.heightMm,
    required this.price,
    required this.color,
  });

  /// Lens merkezleri arası mesafe
  double get pdMm => lensMm + bridgeMm;

  /// Çerçevenin toplam ön genişliği (menteşe uçları dahil)
  double get totalWidthMm => lensMm * 2 + bridgeMm + 12;
}

/// Katalog: kendi modellerinizle değiştirin.
const kCatalog = <EyeFrame>[
  EyeFrame(code: 'GS-101', name: 'Milano', shape: FrameShape.round, lensMm: 48, bridgeMm: 20, heightMm: 46, price: 2450, color: Color(0xFF8A6A2F)),
  EyeFrame(code: 'GS-102', name: 'Torino', shape: FrameShape.oval, lensMm: 50, bridgeMm: 18, heightMm: 40, price: 1990, color: Color(0xFF2B2B2B)),
  EyeFrame(code: 'GS-103', name: 'Berlin', shape: FrameShape.square, lensMm: 52, bridgeMm: 18, heightMm: 44, price: 2250, color: Color(0xFF1B3A5C)),
  EyeFrame(code: 'GS-104', name: 'Londra', shape: FrameShape.rectangle, lensMm: 54, bridgeMm: 17, heightMm: 38, price: 2100, color: Color(0xFF5B3A29)),
  EyeFrame(code: 'GS-105', name: 'Capri', shape: FrameShape.aviator, lensMm: 56, bridgeMm: 16, heightMm: 48, price: 2890, color: Color(0xFFB59A5B)),
  EyeFrame(code: 'GS-106', name: 'Paris', shape: FrameShape.catEye, lensMm: 53, bridgeMm: 17, heightMm: 42, price: 2690, color: Color(0xFF8B1E3F)),
];
