import '../models/models.dart';
import 'face_analyzer.dart';

// Sütun sırası: round, oval, square, rectangle, aviator, catEye
// Değerler 0-1: yüz şekli ile çerçeve şeklinin görsel uyumu (optisyen kuralları).
const _compat = <FaceShape, List<double>>{
  FaceShape.oval:   [0.85, 1.00, 0.90, 1.00, 0.90, 0.85],
  FaceShape.round:  [0.30, 0.50, 0.95, 1.00, 0.65, 0.80],
  FaceShape.square: [1.00, 1.00, 0.30, 0.40, 0.85, 0.60],
  FaceShape.heart:  [0.85, 1.00, 0.60, 0.65, 0.90, 0.50],
  FaceShape.oblong: [1.00, 0.60, 0.90, 0.30, 0.80, 0.70],
};

class FitScore {
  final int total;
  final double shapeFit, sizeFit, eyeFit;
  final List<String> reasons;
  const FitScore(this.total, this.shapeFit, this.sizeFit, this.eyeFit, this.reasons);
}

/// 100 üzerinden uyum puanı: şekil uyumu 55 + boyut oranı 30 + göz hizası 15.
FitScore scoreFrame(EyeFrame f, FaceShape face, FaceGeometry g, double faceWidthMm) {
  final shapeFit = _compat[face]![f.shape.index];

  final ratio = f.totalWidthMm / faceWidthMm; // ideal ~1.0
  final sizeFit = (1 - (ratio - 1.0).abs() / 0.14).clamp(0.0, 1.0).toDouble();

  final pdMm = g.pupilDistPx * faceWidthMm / g.cheekPx;
  final eyeFit = (1 - (f.pdMm - pdMm).abs() / 12).clamp(0.0, 1.0).toDouble();

  final total = (shapeFit * 55 + sizeFit * 30 + eyeFit * 15).round();

  final r = <String>[];
  if (shapeFit >= 0.85) {
    r.add('${f.shape.tr} çerçeve, ${face.tr} yüz hatlarını dengeliyor');
  } else if (shapeFit <= 0.45) {
    r.add('${f.shape.tr} hatlar ${face.tr} yüzde fazla vurgu yaratıyor');
  }
  if (ratio < 0.92) {
    r.add('Çerçeve yüze göre dar kalıyor');
  } else if (ratio > 1.08) {
    r.add('Çerçeve yüze göre geniş kalıyor');
  } else {
    r.add('Çerçeve genişliği yüzünüzle orantılı');
  }
  if (eyeFit < 0.5) {
    r.add('Gözler lens merkezinden kayıyor');
  } else if (eyeFit >= 0.8) {
    r.add('Gözler lens merkezine iyi oturuyor');
  }

  return FitScore(total, shapeFit, sizeFit, eyeFit, r.take(2).toList());
}
