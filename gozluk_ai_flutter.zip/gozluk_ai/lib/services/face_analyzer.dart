import 'dart:math' as math;
import 'dart:ui';
import 'package:google_mlkit_face_mesh_detection/google_mlkit_face_mesh_detection.dart';
import '../models/models.dart';

/// Yüz şekli eşikleri. Gerçek müşterilerle birkaç gün deneyip kalibre edin
/// (uygulamada üstteki yüz şekli etiketine dokununca ham oranlar görünür).
class FaceConfig {
  static const oblongMinLength = 1.40;   // yüz uzunluğu / elmacık genişliği
  static const heartMinForehead = 0.90;  // alın / elmacık
  static const heartMaxJaw = 0.74;       // çene / elmacık
  static const squareMinJaw = 0.86;
  static const roundMaxLength = 1.22;
  static const window = 24;              // ortalama alınan kare sayısı
  static const minSamples = 12;
}

/// Tek bir karede yüzün ölçüleri (piksel, dik görüntü koordinatında).
class FaceGeometry {
  final Size imageSize;
  final Offset eyeCenter;
  final double rollRad, cheekPx, pupilDistPx;
  final double lengthToCheek, jawToCheek, foreheadToCheek;

  const FaceGeometry({
    required this.imageSize,
    required this.eyeCenter,
    required this.rollRad,
    required this.cheekPx,
    required this.pupilDistPx,
    required this.lengthToCheek,
    required this.jawToCheek,
    required this.foreheadToCheek,
  });

  factory FaceGeometry.fromMesh(FaceMesh mesh, Size imageSize) {
    Offset p(int i) => Offset(mesh.points[i].x, mesh.points[i].y);
    double d(int a, int b) => (p(a) - p(b)).distance;

    final e1 = (p(33) + p(133)) / 2;   // bir gözün merkezi
    final e2 = (p(362) + p(263)) / 2;  // diğer gözün merkezi
    final a = e1.dx <= e2.dx ? e1 : e2;
    final b = e1.dx <= e2.dx ? e2 : e1;
    final cheek = d(234, 454);

    return FaceGeometry(
      imageSize: imageSize,
      eyeCenter: (a + b) / 2,
      rollRad: math.atan2(b.dy - a.dy, b.dx - a.dx),
      cheekPx: cheek,
      pupilDistPx: (b - a).distance,
      lengthToCheek: d(10, 152) / cheek,
      jawToCheek: d(172, 397) / cheek,
      foreheadToCheek: d(54, 284) / cheek,
    );
  }

  /// Titremeyi azaltmak için önceki kareyle yumuşatma (a = yeni karenin ağırlığı).
  FaceGeometry smoothed(FaceGeometry? prev, [double a = 0.5]) {
    if (prev == null) return this;
    double m(double n, double o) => o + (n - o) * a;
    return FaceGeometry(
      imageSize: imageSize,
      eyeCenter: Offset.lerp(prev.eyeCenter, eyeCenter, a)!,
      rollRad: m(rollRad, prev.rollRad),
      cheekPx: m(cheekPx, prev.cheekPx),
      pupilDistPx: m(pupilDistPx, prev.pupilDistPx),
      lengthToCheek: lengthToCheek,
      jawToCheek: jawToCheek,
      foreheadToCheek: foreheadToCheek,
    );
  }
}

FaceShape classifyFace(double length, double jaw, double forehead) {
  if (length >= FaceConfig.oblongMinLength) return FaceShape.oblong;
  if (forehead >= FaceConfig.heartMinForehead && jaw <= FaceConfig.heartMaxJaw) {
    return FaceShape.heart;
  }
  if (jaw >= FaceConfig.squareMinJaw) return FaceShape.square;
  if (length <= FaceConfig.roundMaxLength) return FaceShape.round;
  return FaceShape.oval;
}

/// Son N karenin ortalamasıyla kararlı bir yüz şekli üretir.
class FaceAggregator {
  final _l = <double>[], _j = <double>[], _f = <double>[];

  void add(FaceGeometry g) {
    _push(_l, g.lengthToCheek);
    _push(_j, g.jawToCheek);
    _push(_f, g.foreheadToCheek);
  }

  void _push(List<double> a, double v) {
    a.add(v);
    if (a.length > FaceConfig.window) a.removeAt(0);
  }

  void reset() {
    _l.clear();
    _j.clear();
    _f.clear();
  }

  double _avg(List<double> a) =>
      a.isEmpty ? 0 : a.reduce((x, y) => x + y) / a.length;

  bool get ready => _l.length >= FaceConfig.minSamples;
  double get length => _avg(_l);
  double get jaw => _avg(_j);
  double get forehead => _avg(_f);
  FaceShape? get shape => ready ? classifyFace(length, jaw, forehead) : null;
}
